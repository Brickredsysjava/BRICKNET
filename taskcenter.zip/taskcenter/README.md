# BRICKNET


BrickNet offers a flexible and easy to use Human Resource Information System solution 

for small and medium sized companies free of charge. By providing modules for personnel 

information management, employee self-service, leave, time & attendance, benefits and recruitment 

companies are able to manage the crucial organization asset - people. The combination of these 

modules into one application assures the perfect platform for re-engineering and aligning your HR 

processes along with the organizational goals. 
