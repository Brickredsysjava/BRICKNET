package com.BrickNet.TaskCenter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
