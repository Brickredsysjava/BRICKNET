package com.BrickNet.TaskCenter.model;

public enum Priority {
    high,mid,low
}
