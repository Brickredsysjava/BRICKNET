package com.BrickNet.TaskCenter.exception;

public class TodoException extends Exception{

    public TodoException() {

    }
    public TodoException(String message) {
        super(message);
    }
}
