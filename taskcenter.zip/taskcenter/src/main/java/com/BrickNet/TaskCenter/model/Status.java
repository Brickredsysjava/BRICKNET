package com.BrickNet.TaskCenter.model;

public enum Status {
    Initial,Completed, onHold, InProgress
}
